#leap Year
def isLeapYear(Year):
  if(Year % 4==0 and Year % 100!=0)or Year % 400==0:
    return True
  else:
    return False
Year=2012
if isLeapYear(Year):
  print("{} is a leap Year".format(Year))
else:
   print("{}is not aleap Year".format(Year))